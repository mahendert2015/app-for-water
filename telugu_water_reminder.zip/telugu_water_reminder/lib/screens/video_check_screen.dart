import 'dart:async';
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:permission_handler/permission_handler.dart';

/// On-device live video verification screen.
/// Processes camera frames strictly in memory via Google ML Kit Face Detection.
/// NEVER records, saves, or uploads any video or photo.
class VideoCheckScreen extends StatefulWidget {
  const VideoCheckScreen({super.key});

  @override
  State<VideoCheckScreen> createState() => _VideoCheckScreenState();
}

class _VideoCheckScreenState extends State<VideoCheckScreen> {
  CameraController? _controller;
  late final FaceDetector _faceDetector;

  bool _initializing = true;
  String? _errorMessage;
  bool _isProcessingFrame = false;

  // Liveness & drinking verification state
  bool _blinkDetected = false;
  bool _eyesWereClosed = false;
  double _drinkProgress = 0.0; // 0.0 -> 1.0 over ~4 seconds of live face tracking
  DateTime? _lastFrameCheck;
  bool _completed = false;

  String _statusText =
      'కెమెరా వైపు చూసి ఒకసారి కళ్ళు ఆర్పండి (Look at camera & blink)';

  @override
  void initState() {
    super.initState();
    _faceDetector = FaceDetector(
      options: FaceDetectorOptions(
        enableClassification: true,
        enableTracking: true,
        enableLandmarks: true,
        performanceMode: FaceDetectorMode.fast,
      ),
    );
    _initCamera();
  }

  Future<void> _initCamera() async {
    final status = await Permission.camera.request();
    if (!status.isGranted) {
      if (!mounted) return;
      setState(() {
        _initializing = false;
        _errorMessage =
            'Camera permission is required for live drinking verification.';
      });
      return;
    }

    try {
      final cameras = await availableCameras();
      final front = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      final controller = CameraController(
        front,
        ResolutionPreset.medium,
        enableAudio: false,
        imageFormatGroup: Platform.isAndroid
            ? ImageFormatGroup.nv21
            : ImageFormatGroup.bgra8888,
      );

      await controller.initialize();
      await controller.startImageStream(_processCameraImage);

      if (!mounted) return;
      setState(() {
        _controller = controller;
        _initializing = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _initializing = false;
        _errorMessage = 'Could not start camera: $e';
      });
    }
  }

  Future<void> _processCameraImage(CameraImage image) async {
    if (_isProcessingFrame || _completed || _controller == null) return;
    _isProcessingFrame = true;

    try {
      final inputImage = _toInputImage(image);
      if (inputImage == null) {
        _isProcessingFrame = false;
        return;
      }

      final faces = await _faceDetector.processImage(inputImage);
      if (!mounted) return;

      if (faces.isEmpty) {
        setState(() {
          _statusText = 'మీ ముఖం కెమెరాలో కనిపించడం లేదు — దయచేసి ముందు ఉండండి';
        });
      } else {
        final face = faces.first;
        final leftEye = face.leftEyeOpenProbability ?? 1.0;
        final rightEye = face.rightEyeOpenProbability ?? 1.0;

        // Step 1: Liveness check via natural blink (anti-spoofing)
        if (!_blinkDetected) {
          if (leftEye < 0.35 && rightEye < 0.35) {
            _eyesWereClosed = true;
          } else if (_eyesWereClosed && leftEye > 0.65 && rightEye > 0.65) {
            _blinkDetected = true;
            _lastFrameCheck = DateTime.now();
          }
          setState(() {
            _statusText = _blinkDetected
                ? 'లైవ్ చెక్ ఓకే! ఇప్పుడు నీళ్ళు తాగుతూ 4 సెకన్లు ఉండండి...'
                : 'కెమెరా వైపు చూసి ఒకసారి కళ్ళు ఆర్పండి (Blink to verify live)';
          });
        } else {
          // Step 2: Sustained 4-second live check while drinking water
          final now = DateTime.now();
          final dt = _lastFrameCheck == null
              ? 0.1
              : now.difference(_lastFrameCheck!).inMilliseconds / 1000.0;
          _lastFrameCheck = now;

          final nextProgress = (_drinkProgress + dt / 4.0).clamp(0.0, 1.0);
          setState(() {
            _drinkProgress = nextProgress;
            _statusText =
                'నీళ్ళు తాగండి... ${(nextProgress * 100).round()}% పూర్తి';
          });

          if (nextProgress >= 1.0 && !_completed) {
            _completed = true;
            await _finishSuccess();
          }
        }
      }
    } catch (_) {
      // Ignore transient frame conversion errors
    } finally {
      _isProcessingFrame = false;
    }
  }

  InputImage? _toInputImage(CameraImage image) {
    final camera = _controller?.description;
    if (camera == null) return null;

    final rotation =
        InputImageRotationValue.fromRawValue(camera.sensorOrientation) ??
            InputImageRotation.rotation0deg;

    final format = Platform.isAndroid
        ? InputImageFormat.nv21
        : InputImageFormat.bgra8888;

    final plane = image.planes.first;
    final WriteBuffer allBytes = WriteBuffer();
    for (final p in image.planes) {
      allBytes.putUint8List(p.bytes);
    }
    final bytes = allBytes.done().buffer.asUint8List();

    return InputImage.fromBytes(
      bytes: bytes,
      metadata: InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: rotation,
        format: format,
        bytesPerRow: plane.bytesPerRow,
      ),
    );
  }

  Future<void> _finishSuccess() async {
    try {
      await _controller?.stopImageStream();
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  void dispose() {
    _controller?.dispose();
    _faceDetector.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Live Drinking Check (No Upload)'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
      ),
      body: _initializing
          ? const Center(child: CircularProgressIndicator())
          : _errorMessage != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : Stack(
                  fit: StackFit.expand,
                  children: [
                    if (_controller != null && _controller!.value.isInitialized)
                      CameraPreview(_controller!),
                    Positioned(
                      left: 16,
                      right: 16,
                      bottom: 32,
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.72),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _statusText,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 12),
                            LinearProgressIndicator(
                              value: _blinkDetected ? _drinkProgress : 0.0,
                              minHeight: 10,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'Privacy: Processed live on-device only. Nothing is saved or uploaded.',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }
}
