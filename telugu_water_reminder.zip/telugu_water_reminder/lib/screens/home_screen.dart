import 'dart:math';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/app_settings.dart';
import '../models/hydration_log.dart';
import '../services/notification_service.dart';
import '../services/partner_sync_service.dart';
import '../services/storage_service.dart';
import '../services/telugu_voice_service.dart';
import 'settings_screen.dart';
import 'video_check_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final StorageService _storage = StorageService();
  final TeluguVoiceService _voice = TeluguVoiceService();
  final NotificationService _notifications = NotificationService();
  final PartnerSyncService _partnerSync = PartnerSyncService();
  final Random _random = Random();

  AppSettings _settings = const AppSettings();
  List<HydrationLog> _todayLogs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _notifications.onNotificationTapped = _handleNotificationTap;
    _loadData();
  }

  Future<void> _loadData() async {
    final settings = await _storage.loadSettings();
    final logs = await _storage.loadTodayLogs();
    await _notifications.scheduleHourlyReminders(settings);
    if (!mounted) return;
    setState(() {
      _settings = settings;
      _todayLogs = logs;
      _loading = false;
    });
  }

  Future<void> _handleNotificationTap(bool requireVideo) async {
    if (_settings.teluguVoiceEnabled) {
      await _voice.speakReminder(isVideoCheck: requireVideo);
    }
    if (!mounted) return;
    if (requireVideo) {
      await _startVideoVerification();
    } else {
      await _logWater(requireRandomCheck: false);
    }
  }

  Future<void> _logWater({bool requireRandomCheck = true}) async {
    final shouldVerifyVideo = requireRandomCheck &&
        _random.nextDouble() < _settings.videoCheckProbability;

    if (shouldVerifyVideo) {
      if (_settings.teluguVoiceEnabled) {
        await _voice.speakReminder(isVideoCheck: true);
      }
      if (!mounted) return;
      await _startVideoVerification();
      return;
    }

    await _saveLog(verifiedByVideo: false);
  }

  Future<void> _startVideoVerification() async {
    final verified = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => const VideoCheckScreen(),
      ),
    );
    if (verified == true) {
      await _saveLog(verifiedByVideo: true);
    }
  }

  Future<void> _saveLog({required bool verifiedByVideo}) async {
    final log = HydrationLog(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      timestamp: DateTime.now(),
      amountMl: _settings.glassSizeMl,
      verifiedByVideo: verifiedByVideo,
      phoneRole: _settings.phoneRole,
    );
    await _storage.addLog(log);
    await _partnerSync.pushLog(_settings, log);
    if (_settings.teluguVoiceEnabled) {
      await _voice.speakSuccess();
    }
    await _loadData();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          verifiedByVideo
              ? 'లైవ్ వీడియో చెక్ పూర్తయింది! +${_settings.glassSizeMl} ml logged'
              : 'నీళ్ళు తాగినట్లు నమోదు అయింది! +${_settings.glassSizeMl} ml logged',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final progress = _settings.dailyGoalGlasses > 0
        ? (_todayLogs.length / _settings.dailyGoalGlasses).clamp(0.0, 1.0)
        : 0.0;
    final totalMl = _todayLogs.fold<int>(0, (sum, l) => sum + l.amountMl);
    final videoVerifiedCount =
        _todayLogs.where((l) => l.verifiedByVideo).length;

    return Scaffold(
      appBar: AppBar(
        title: Text('${_settings.userName} • Water Reminder'),
        actions: [
          IconButton(
            tooltip: 'Test Telugu Voice',
            icon: const Icon(Icons.volume_up),
            onPressed: () => _voice.speakReminder(),
          ),
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(Icons.settings),
            onPressed: () async {
              final updated = await Navigator.of(context).push<bool>(
                MaterialPageRoute(
                  builder: (_) => SettingsScreen(initialSettings: _settings),
                ),
              );
              if (updated == true) {
                await _loadData();
              }
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadData,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _buildProgressCard(progress, totalMl, videoVerifiedCount),
                  const SizedBox(height: 16),
                  _buildActionButtons(),
                  const SizedBox(height: 20),
                  _buildScheduleInfoCard(),
                  const SizedBox(height: 20),
                  Text(
                    "Today's Hydration Log",
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 8),
                  if (_todayLogs.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Text(
                          'ఇంకా ఈరోజు నీళ్ళు నమోదు చేయలేదు.\nTap "Drink Water Now" to log your first glass!',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  else
                    ..._todayLogs.map(_buildLogTile),
                ],
              ),
            ),
    );
  }

  Widget _buildProgressCard(
      double progress, int totalMl, int videoVerifiedCount) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${_todayLogs.length} / ${_settings.dailyGoalGlasses} Glasses',
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    const SizedBox(height: 4),
                    Text('$totalMl ml • $videoVerifiedCount video-verified'),
                  ],
                ),
                Chip(
                  avatar: const Icon(Icons.phone_android, size: 18),
                  label: Text(
                    _settings.phoneRole == 'wife' ? "Wife's Phone" : 'My Phone',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: progress,
              minHeight: 12,
              borderRadius: BorderRadius.circular(8),
            ),
            const SizedBox(height: 12),
            Text(
              'నీళ్ళు తాగండి — ఆరోగ్యంగా ఉండండి!',
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          height: 54,
          child: FilledButton.icon(
            onPressed: () => _logWater(requireRandomCheck: true),
            icon: const Icon(Icons.local_drink),
            label: const Text(
              'Drink Water Now (Random Video Check)',
              style: TextStyle(fontSize: 16),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _startVideoVerification,
                icon: const Icon(Icons.videocam),
                label: const Text('Live Video Check'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () =>
                    _notifications.showTestNotification(requireVideo: true),
                icon: const Icon(Icons.notifications_active),
                label: const Text('Test Alert'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildScheduleInfoCard() {
    final pct = (_settings.videoCheckProbability * 100).round();
    return Card(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Active Schedule & Privacy',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(
              '• Hourly Telugu alerts: ${_settings.wakeHour}:00 – ${_settings.sleepHour}:00\n'
              '• Random live video check chance: $pct%\n'
              '• 100% On-device camera check — zero video saved or uploaded',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogTile(HydrationLog log) {
    final timeStr = DateFormat('h:mm a').format(log.timestamp);
    return Card(
      child: ListTile(
        leading: Icon(
          log.verifiedByVideo ? Icons.verified_user : Icons.water_drop,
          color: log.verifiedByVideo ? Colors.green : Colors.blue,
        ),
        title: Text('${log.amountMl} ml at $timeStr'),
        subtitle: Text(
          log.verifiedByVideo
              ? 'Verified live on-device (no video saved)'
              : 'Quick tap log',
        ),
      ),
    );
  }
}
