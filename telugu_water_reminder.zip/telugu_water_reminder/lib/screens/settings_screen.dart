import 'package:flutter/material.dart';
import '../models/app_settings.dart';
import '../services/storage_service.dart';

class SettingsScreen extends StatefulWidget {
  final AppSettings initialSettings;

  const SettingsScreen({super.key, required this.initialSettings});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final StorageService _storage = StorageService();
  late AppSettings _settings;
  late TextEditingController _userNameController;
  late TextEditingController _coupleCodeController;

  @override
  void initState() {
    super.initState();
    _settings = widget.initialSettings;
    _userNameController = TextEditingController(text: _settings.userName);
    _coupleCodeController = TextEditingController(text: _settings.coupleCode);
  }

  @override
  void dispose() {
    _userNameController.dispose();
    _coupleCodeController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final updated = _settings.copyWith(
      userName: _userNameController.text.trim().isEmpty
          ? 'My Phone'
          : _userNameController.text.trim(),
      coupleCode: _coupleCodeController.text.trim(),
    );
    await _storage.saveSettings(updated);
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reminder Settings'),
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text('SAVE'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Phone Profile',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'husband', label: Text('My Phone')),
              ButtonSegment(value: 'wife', label: Text("Wife's Phone")),
            ],
            selected: {_settings.phoneRole},
            onSelectionChanged: (val) {
              final role = val.first;
              setState(() {
                _settings = _settings.copyWith(phoneRole: role);
                if (_userNameController.text == 'My Phone' ||
                    _userNameController.text == "Wife's Phone") {
                  _userNameController.text =
                      role == 'wife' ? "Wife's Phone" : 'My Phone';
                }
              });
            },
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _userNameController,
            decoration: const InputDecoration(
              labelText: 'Display Name',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          SwitchListTile(
            title: const Text('Telugu Voice Reminders (తెలుగు వాయిస్)'),
            subtitle: const Text('Speak Telugu prompts when logging or opening'),
            value: _settings.teluguVoiceEnabled,
            onChanged: (v) =>
                setState(() => _settings = _settings.copyWith(teluguVoiceEnabled: v)),
          ),
          const Divider(),
          ListTile(
            title: Text(
                'Random Video Check Chance: ${(_settings.videoCheckProbability * 100).round()}%'),
            subtitle: Slider(
              value: _settings.videoCheckProbability,
              min: 0.0,
              max: 1.0,
              divisions: 10,
              label: '${(_settings.videoCheckProbability * 100).round()}%',
              onChanged: (v) => setState(
                  () => _settings = _settings.copyWith(videoCheckProbability: v)),
            ),
          ),
          ListTile(
            title: Text('Daily Goal: ${_settings.dailyGoalGlasses} glasses'),
            subtitle: Slider(
              value: _settings.dailyGoalGlasses.toDouble(),
              min: 4,
              max: 16,
              divisions: 12,
              onChanged: (v) => setState(
                  () => _settings = _settings.copyWith(dailyGoalGlasses: v.round())),
            ),
          ),
          Row(
            children: [
              Expanded(
                child: ListTile(
                  title: const Text('Start Hour'),
                  subtitle: Text('${_settings.wakeHour}:00'),
                  trailing: DropdownButton<int>(
                    value: _settings.wakeHour,
                    items: List.generate(12, (i) => i + 5)
                        .map((h) => DropdownMenuItem(value: h, child: Text('$h:00')))
                        .toList(),
                    onChanged: (h) {
                      if (h != null) {
                        setState(() => _settings = _settings.copyWith(wakeHour: h));
                      }
                    },
                  ),
                ),
              ),
              Expanded(
                child: ListTile(
                  title: const Text('End Hour'),
                  subtitle: Text('${_settings.sleepHour}:00'),
                  trailing: DropdownButton<int>(
                    value: _settings.sleepHour,
                    items: List.generate(7, (i) => i + 18)
                        .map((h) => DropdownMenuItem(value: h, child: Text('$h:00')))
                        .toList(),
                    onChanged: (h) {
                      if (h != null && h > _settings.wakeHour) {
                        setState(() => _settings = _settings.copyWith(sleepHour: h));
                      }
                    },
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _coupleCodeController,
            decoration: const InputDecoration(
              labelText: 'Optional Couple Sync Code',
              helperText: 'Leave blank for 100% offline mode on both phones',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
    );
  }
}
