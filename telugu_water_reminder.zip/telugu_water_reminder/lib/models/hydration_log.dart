class HydrationLog {
  final String id;
  final DateTime timestamp;
  final int amountMl;
  final bool verifiedByVideo;
  final String phoneRole; // 'husband' or 'wife'

  const HydrationLog({
    required this.id,
    required this.timestamp,
    required this.amountMl,
    required this.verifiedByVideo,
    required this.phoneRole,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'timestamp': timestamp.toIso8601String(),
        'amountMl': amountMl,
        'verifiedByVideo': verifiedByVideo,
        'phoneRole': phoneRole,
      };

  factory HydrationLog.fromJson(Map<String, dynamic> json) => HydrationLog(
        id: json['id'] as String,
        timestamp: DateTime.parse(json['timestamp'] as String),
        amountMl: json['amountMl'] as int? ?? 250,
        verifiedByVideo: json['verifiedByVideo'] as bool? ?? false,
        phoneRole: json['phoneRole'] as String? ?? 'husband',
      );
}
