class AppSettings {
  final String phoneRole; // 'husband' or 'wife'
  final String userName;
  final String partnerName;
  final int wakeHour; // 24h format, e.g. 7
  final int sleepHour; // 24h format, e.g. 22
  final int dailyGoalGlasses;
  final int glassSizeMl;
  final double videoCheckProbability; // 0.0 to 1.0 (default 0.35 = 35%)
  final bool teluguVoiceEnabled;
  final String coupleCode; // Optional pairing code for Firebase sync

  const AppSettings({
    this.phoneRole = 'husband',
    this.userName = 'My Phone',
    this.partnerName = "Wife's Phone",
    this.wakeHour = 7,
    this.sleepHour = 22,
    this.dailyGoalGlasses = 10,
    this.glassSizeMl = 250,
    this.videoCheckProbability = 0.35,
    this.teluguVoiceEnabled = true,
    this.coupleCode = '',
  });

  AppSettings copyWith({
    String? phoneRole,
    String? userName,
    String? partnerName,
    int? wakeHour,
    int? sleepHour,
    int? dailyGoalGlasses,
    int? glassSizeMl,
    double? videoCheckProbability,
    bool? teluguVoiceEnabled,
    String? coupleCode,
  }) {
    return AppSettings(
      phoneRole: phoneRole ?? this.phoneRole,
      userName: userName ?? this.userName,
      partnerName: partnerName ?? this.partnerName,
      wakeHour: wakeHour ?? this.wakeHour,
      sleepHour: sleepHour ?? this.sleepHour,
      dailyGoalGlasses: dailyGoalGlasses ?? this.dailyGoalGlasses,
      glassSizeMl: glassSizeMl ?? this.glassSizeMl,
      videoCheckProbability:
          videoCheckProbability ?? this.videoCheckProbability,
      teluguVoiceEnabled: teluguVoiceEnabled ?? this.teluguVoiceEnabled,
      coupleCode: coupleCode ?? this.coupleCode,
    );
  }

  Map<String, dynamic> toJson() => {
        'phoneRole': phoneRole,
        'userName': userName,
        'partnerName': partnerName,
        'wakeHour': wakeHour,
        'sleepHour': sleepHour,
        'dailyGoalGlasses': dailyGoalGlasses,
        'glassSizeMl': glassSizeMl,
        'videoCheckProbability': videoCheckProbability,
        'teluguVoiceEnabled': teluguVoiceEnabled,
        'coupleCode': coupleCode,
      };

  factory AppSettings.fromJson(Map<String, dynamic> json) => AppSettings(
        phoneRole: json['phoneRole'] as String? ?? 'husband',
        userName: json['userName'] as String? ?? 'My Phone',
        partnerName: json['partnerName'] as String? ?? "Wife's Phone",
        wakeHour: json['wakeHour'] as int? ?? 7,
        sleepHour: json['sleepHour'] as int? ?? 22,
        dailyGoalGlasses: json['dailyGoalGlasses'] as int? ?? 10,
        glassSizeMl: json['glassSizeMl'] as int? ?? 250,
        videoCheckProbability:
            (json['videoCheckProbability'] as num?)?.toDouble() ?? 0.35,
        teluguVoiceEnabled: json['teluguVoiceEnabled'] as bool? ?? true,
        coupleCode: json['coupleCode'] as String? ?? '',
      );
}
