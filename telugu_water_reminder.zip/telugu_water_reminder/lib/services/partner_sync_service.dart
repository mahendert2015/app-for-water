import '../models/app_settings.dart';
import '../models/hydration_log.dart';

/// Optional Partner Sync Service for My Phone & Wife's Phone.
///
/// By default, the app runs 100% offline on both phones with zero server setup.
/// If you want both phones to see each other's daily glass count (never videos),
/// follow the optional Firebase Firestore steps in README.md and implement
/// [pushLog] and [fetchPartnerTodayCount] here.
class PartnerSyncService {
  Future<void> pushLog(AppSettings settings, HydrationLog log) async {
    if (settings.coupleCode.trim().isEmpty) return;
    // Hook for optional Firebase Firestore sync:
    // Collection: couples/{coupleCode}/logs
    // Only syncs: phoneRole, timestamp, verifiedByVideo (NEVER any video/photo).
  }

  Future<int?> fetchPartnerTodayCount(AppSettings settings) async {
    if (settings.coupleCode.trim().isEmpty) return null;
    // Hook for optional Firebase Firestore query for partner's today count.
    return null;
  }
}
