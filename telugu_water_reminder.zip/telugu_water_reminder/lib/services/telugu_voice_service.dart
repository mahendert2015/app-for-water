import 'dart:math';
import 'package:flutter_tts/flutter_tts.dart';

class TeluguVoiceService {
  final FlutterTts _tts = FlutterTts();
  final Random _random = Random();
  bool _initialized = false;

  static const List<String> reminderPhrases = [
    'నమస్కారం! నీళ్ళు తాగే సమయం అయింది. దయచేసి ఒక గ్లాసు మంచి నీళ్ళు తాగండి.',
    'గంట అయింది! హైడ్రేటెడ్‌గా ఉండడానికి ఇప్పుడే నీళ్ళు తాగండి.',
    'మీ ఆరోగ్యం కోసం ఇప్పుడే ఒక గ్లాసు నీళ్ళు తాగండి.',
    'నీళ్ళు తాగడం మర్చిపోకండి. దయచేసి ఒక గ్లాసు నీళ్ళు తాగండి.',
    'సమయానికి నీళ్ళు తాగి ఆరోగ్యంగా ఉండండి!',
  ];

  static const List<String> videoCheckPhrases = [
    'ఈసారి వీడియో చెక్ ఉంది! కెమెరా ముందు నీళ్ళు తాగుతూ చూపించండి.',
    'లైవ్ చెక్ సమయం! దయచేసి కెమెరా వైపు చూసి నీళ్ళు తాగండి.',
  ];

  static const List<String> successPhrases = [
    'చాలా బాగుంది! నీళ్ళు తాగినందుకు ధన్యవాదాలు.',
    'సూపర్! ఇలాగే రోజూ సమయానికి నీళ్ళు తాగండి.',
  ];

  Future<void> init() async {
    if (_initialized) return;
    await _tts.setLanguage('te-IN');
    await _tts.setSpeechRate(0.45);
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);
    _initialized = true;
  }

  Future<void> speakReminder({bool isVideoCheck = false}) async {
    await init();
    final list = isVideoCheck ? videoCheckPhrases : reminderPhrases;
    final phrase = list[_random.nextInt(list.length)];
    await _tts.stop();
    await _tts.speak(phrase);
  }

  Future<void> speakSuccess() async {
    await init();
    final phrase = successPhrases[_random.nextInt(successPhrases.length)];
    await _tts.stop();
    await _tts.speak(phrase);
  }

  Future<void> stop() async {
    await _tts.stop();
  }
}
