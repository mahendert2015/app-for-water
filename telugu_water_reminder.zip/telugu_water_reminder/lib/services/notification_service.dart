import 'dart:math';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../models/app_settings.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  final Random _random = Random();

  static const String _channelId = 'telugu_water_reminder_channel_v1';
  static const String _channelName = 'Telugu Water Reminders';
  static const String _channelDesc =
      'Hourly Telugu voice reminders to drink water';

  void Function(bool requireVideo)? onNotificationTapped;

  Future<void> init() async {
    tz.initializeTimeZones();
    // Default to Asia/Kolkata; works cleanly for IST and can be adjusted if needed.
    try {
      tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));
    } catch (_) {
      tz.setLocalLocation(tz.UTC);
    }

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    await _plugin.initialize(
      settings: const InitializationSettings(android: androidInit, iOS: iosInit),
      onDidReceiveNotificationResponse: (details) {
        final requireVideo = details.payload == 'video_check';
        onNotificationTapped?.call(requireVideo);
      },
    );

    final androidPlugin = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.requestExactAlarmsPermission();
  }

  Future<void> scheduleHourlyReminders(AppSettings settings) async {
    await _plugin.cancelAll();

    final now = tz.TZDateTime.now(tz.local);
    int idCounter = 100;

    for (int hour = settings.wakeHour; hour <= settings.sleepHour; hour++) {
      var scheduled = tz.TZDateTime(
        tz.local,
        now.year,
        now.month,
        now.day,
        hour,
        0,
      );
      if (scheduled.isBefore(now)) {
        scheduled = scheduled.add(const Duration(days: 1));
      }

      // Randomly tag ~35% (configurable) of hourly reminders as Video Check
      final requireVideo =
          _random.nextDouble() < settings.videoCheckProbability;

      final androidDetails = AndroidNotificationDetails(
        _channelId,
        _channelName,
        channelDescription: _channelDesc,
        importance: Importance.max,
        priority: Priority.high,
        sound: const RawResourceAndroidNotificationSound(
          'telugu_water_reminder',
        ),
        playSound: true,
        enableVibration: true,
      );

      const iosDetails = DarwinNotificationDetails(
        sound: 'telugu_water_reminder.wav',
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      );

      await _plugin.zonedSchedule(
        id: idCounter++,
        title: requireVideo
            ? 'నీళ్ళు తాగే సమయం! (Video Check)'
            : 'నీళ్ళు తాగే సమయం అయింది!',
        body: requireVideo
            ? 'ఒక గ్లాసు నీళ్ళు తాగుతూ లైవ్ వీడియో చెక్ చేయండి.'
            : 'దయచేసి ఇప్పుడే ఒక గ్లాసు మంచి నీళ్ళు తాగండి.',
        scheduledDate: scheduled,
        notificationDetails: NotificationDetails(
          android: androidDetails,
          iOS: iosDetails,
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        matchDateTimeComponents: DateTimeComponents.time,
        payload: requireVideo ? 'video_check' : 'normal',
      );
    }
  }

  Future<void> showTestNotification({required bool requireVideo}) async {
    final androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDesc,
      importance: Importance.max,
      priority: Priority.high,
      sound:
          const RawResourceAndroidNotificationSound('telugu_water_reminder'),
      playSound: true,
    );

    const iosDetails = DarwinNotificationDetails(
      sound: 'telugu_water_reminder.wav',
      presentAlert: true,
      presentSound: true,
    );

    await _plugin.show(
      id: 999,
      title: requireVideo
          ? 'నీళ్ళు తాగే సమయం! (Video Check)'
          : 'నీళ్ళు తాగే సమయం అయింది!',
      body: requireVideo
          ? 'ఒక గ్లాసు నీళ్ళు తాగుతూ లైవ్ వీడియో చెక్ చేయండి.'
          : 'దయచేసి ఇప్పుడే ఒక గ్లాసు మంచి నీళ్ళు తాగండి.',
      notificationDetails: NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      ),
      payload: requireVideo ? 'video_check' : 'normal',
    );
  }
}
