import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_settings.dart';
import '../models/hydration_log.dart';

class StorageService {
  static const _settingsKey = 'app_settings_v1';
  static const _logsKey = 'hydration_logs_v1';

  Future<AppSettings> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_settingsKey);
    if (raw == null) return const AppSettings();
    return AppSettings.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  Future<void> saveSettings(AppSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_settingsKey, jsonEncode(settings.toJson()));
  }

  Future<List<HydrationLog>> loadTodayLogs() async {
    final prefs = await SharedPreferences.getInstance();
    final rawList = prefs.getStringList(_logsKey) ?? [];
    final now = DateTime.now();
    return rawList
        .map((s) => HydrationLog.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .where((log) =>
            log.timestamp.year == now.year &&
            log.timestamp.month == now.month &&
            log.timestamp.day == now.day)
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  Future<void> addLog(HydrationLog log) async {
    final prefs = await SharedPreferences.getInstance();
    final rawList = prefs.getStringList(_logsKey) ?? [];
    rawList.add(jsonEncode(log.toJson()));
    // Keep last 200 entries to stay lightweight
    final trimmed =
        rawList.length > 200 ? rawList.sublist(rawList.length - 200) : rawList;
    await prefs.setStringList(_logsKey, trimmed);
  }
}
